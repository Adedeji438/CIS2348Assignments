'''


name: Adedeji Akingbola
PSID: 1793979
'''

if __name__ == '__main__':
    userNum = int(input())
    userNumSquared = userNum *userNum 
    print(userNumSquared, end='\n') 