'''


name: Adedeji Akingbola
PSID:1793979
'''

if __name__ == '__main__':
    user_num1 =int( input("Enter integer:"))
    print("You entered:" + str(user_num1));
    print(str(user_num1) + " squared is" + str(user_num1 * user_num1))
    print("and " + str(user_num1) + " cubed is " + str(user_num1 * user_num1 * user_num1) + " !!")
    user_num2 = int( input("Enter another integer:"))
    print(str(user_num1)+" + "+str(user_num2)+" is "+str(user_num1 + user_num2));
    print(str(user_num1)+" * "+str(user_num2)+" is "+str(user_num1 * user_num2));
    
   
