'''
Created on 18-Sep-2021

Name: Adedeji Akingbola
Psid: 1793979
'''
import datetime


# Get the month
def getMonth():
    month = 0;
    while(month == 0):
        try:
            month = int(input("Month: "))
            if(month < 1 or month > 12):
                month = 0
        except ValueError:
            month = 0
        if(month == 0):
            print("Invalid Month")
    
    return month


# Get the year
def getYear():
    year = 0;
    while(year == 0):
        try:
            year = int(input("Year: "))
            if(year < 1):
                year = 0
        except ValueError:
            year = 0
        if(year == 0):
            print("Invalid year")
    
    return year


# Get the day
def getDay():
    day = 0;
    while(day == 0):
        try:
            day = int(input("Day: "))
            if(day < 1 or day > 31):
                day = 0
        except ValueError:
            day = 0
        if(day == 0):
            print("Invalid Day")
    
    return day


if __name__ == '__main__':
    print("Birthday Calculator")
    print('Current day')
    valid = False
    date_obj1 = None
    
    while(not valid):
        m1 = getMonth()
        d1 = getDay()
        y1 = getYear()
        date_string = str(y1) + '-' + str(m1) + '-' + str(d1)
        date_format = '%Y-%m-%d'
        try:
            date_obj1 = datetime.datetime.strptime(date_string, date_format)
            valid = True
        except ValueError:
            print("Incorrect data format, should be YYYY-MM-DD")
    valid = False
    print('Birthday')
    date_obj2 = None
    while(not valid):
        m2 = getMonth()
        d2 = getDay()
        y2 = getYear()
        date_string = str(y2) + '-' + str(m2) + '-' + str(d2)
        date_format = '%Y-%m-%d'
        try:
            date_obj2 = datetime.datetime.strptime(date_string, date_format)
            valid = True
        except ValueError:
            print("Incorrect data format, should be YYYY-MM-DD")
    if(date_obj2 < date_obj1):
        years = y1 - y2 - 1
        if(m2 < m1):
            years += 1
        elif(m1 == m2):
            if(d2 < d1):
                years += 1
        if(m1 == m2 and d1 == d2):
            print('Happy Birthday')
        print('You are ' + str(years) + " years old.")
